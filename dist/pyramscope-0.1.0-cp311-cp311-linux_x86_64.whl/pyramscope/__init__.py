from ._pyramscope import get_size
