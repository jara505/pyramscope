#include <pybind11/pybind11.h>

namespace py = pybind11;

size_t get_size(py::object obj) {
    return py::len(obj);
}

PYBIND11_MODULE(_pyramscope, m) {
    m.def("get_size", &get_size, "Devuelve el tamaño de un objeto iterable");
}
